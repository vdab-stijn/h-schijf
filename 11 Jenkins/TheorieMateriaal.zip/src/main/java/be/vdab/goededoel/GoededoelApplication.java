package be.vdab.goededoel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoededoelApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoededoelApplication.class, args);
	}
}
